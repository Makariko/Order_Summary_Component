# order-summary-component

A Pen created on CodePen.io. Original URL: [https://codepen.io/Mariam-Margve/pen/mdxZPrM](https://codepen.io/Mariam-Margve/pen/mdxZPrM).

